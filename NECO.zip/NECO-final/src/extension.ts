import * as vscode from 'vscode';
import { NecoViewProvider } from './NecoViewProvider';

const COMMENT_MAP: { [key: string]: string } = {
	python:          '# [py] : ',
	javascript:      '// [js] : ',
	typescript:      '// [ts] : ',
	typescriptreact: '// [tsx] : ',
	javascriptreact: '// [jsx] : ',
	cpp:             '// [c++] : ',
	c:               '// [c] : ',
	java:            '// [java] : ',
	rust:            '// [rs] : ',
	go:              '// [go] : ',
	kotlin:          '// [kt] : ',
	swift:           '// [swift] : ',
	csharp:          '// [c#] : ',
	php:             '// [php] : ',
	ruby:            '# [rb] : ',
	shellscript:     '# [sh] : ',
	yaml:            '# [yaml] : ',
};

async function addCommentFromSelection() {
	const editor = vscode.window.activeTextEditor;

	if (!editor) {
		vscode.window.showErrorMessage('열린 파일이 없습니다!');
		return;
	}

	const selection = editor.selection;
	const selectedText = editor.document.getText(selection);

	if (!selectedText.trim()) {
		vscode.window.showErrorMessage('코드를 선택해주세요!');
		return;
	}

	const languageId = editor.document.languageId;
	const commentPrefix = COMMENT_MAP[languageId] ?? '// ';
	const startLine = selection.start.line;
	const position = new vscode.Position(startLine, 0);

	const firstLine = selectedText.split('\n')[0].trim().slice(0, 60);
	const comment = `${commentPrefix}${firstLine}${firstLine.length >= 60 ? '...' : ''}\n`;

	await editor.edit(editBuilder => {
		editBuilder.insert(position, comment);
	});
}

function handleSelectionChange(provider: NecoViewProvider): vscode.Disposable {
	let debounceTimer: ReturnType<typeof setTimeout> | undefined;

	return vscode.window.onDidChangeTextEditorSelection(() => {
		clearTimeout(debounceTimer);
		debounceTimer = setTimeout(() => {
			const editor = vscode.window.activeTextEditor;
			if (!editor) return;

			const { selection, document } = editor;
			const text = document.getText(selection);
			const languageId = document.languageId;
			const fileName = document.fileName.split(/[\\/]/).pop() ?? '';

			provider.sendMessage('setCode', JSON.stringify({ code: text, languageId, fileName }));
		}, 200);
	});
}

export function activate(context: vscode.ExtensionContext) {
	const provider = new NecoViewProvider(context.extensionUri);

	context.subscriptions.push(
		vscode.commands.registerCommand('neco.addComment', addCommentFromSelection),
		vscode.window.registerWebviewViewProvider('necoSidebarView', provider),
		handleSelectionChange(provider),
	);
}

export function deactivate() {}
