import { useEffect, useCallback, useMemo, useReducer } from 'react';
import './App.css';

declare function acquireVsCodeApi(): {
  postMessage: (msg: unknown) => void;
};

const vscode = acquireVsCodeApi();

interface CodePayload {
  code: string;
  languageId: string;
  fileName: string;
}

type State = { payload: CodePayload; copied: boolean };
type Action =
  | { type: 'SET_CODE'; payload: CodePayload }
  | { type: 'SET_COPIED'; value: boolean };

const initialState: State = {
  payload: { code: '', languageId: '', fileName: '' },
  copied: false,
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'SET_CODE':
      return { payload: action.payload, copied: false };
    case 'SET_COPIED':
      return { ...state, copied: action.value };
  }
}

const LANG_LABELS: Record<string, string> = {
  javascript: 'JavaScript',
  typescript: 'TypeScript',
  typescriptreact: 'TSX',
  javascriptreact: 'JSX',
  python: 'Python',
  cpp: 'C++',
  c: 'C',
  java: 'Java',
  rust: 'Rust',
  go: 'Go',
  kotlin: 'Kotlin',
  swift: 'Swift',
  csharp: 'C#',
  php: 'PHP',
  ruby: 'Ruby',
  shellscript: 'Shell',
  yaml: 'YAML',
};

function App() {
  const [{ payload, copied }, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    const handler = (event: MessageEvent) => {
      const message = event.data;
      if (message.type === 'setCode') {
        dispatch({ type: 'SET_CODE', payload: JSON.parse(message.text) });
      }
    };
    window.addEventListener('message', handler);
    return () => window.removeEventListener('message', handler);
  }, []);

  const handleCopy = useCallback(() => {
    if (!payload.code || copied) return;
    vscode.postMessage({ type: 'copyToClipboard', text: payload.code });
    dispatch({ type: 'SET_COPIED', value: true });
    setTimeout(() => dispatch({ type: 'SET_COPIED', value: false }), 2000);
  }, [payload.code, copied]);

  const { lineCount, charCount, langLabel } = useMemo(() => ({
    lineCount: payload.code ? payload.code.split('\n').length : 0,
    charCount: payload.code.length,
    langLabel: LANG_LABELS[payload.languageId] ?? payload.languageId ?? '',
  }), [payload.code, payload.languageId]);

  return (
    <div className="neco-root">
      <header className="neco-header">
        <div className="neco-logo">
          <span className="neco-logo-icon">🐱</span>
          <span className="neco-logo-text">NECO</span>
        </div>
        <span className="neco-tagline">코드 도우미</span>
      </header>

      {payload.fileName && (
        <div className="neco-filebar">
          <span className="neco-filename">📄 {payload.fileName}</span>
          {langLabel && <span className="neco-lang-badge">{langLabel}</span>}
        </div>
      )}

      <div className="neco-code-section">
        {payload.code ? (
          <>
            <div className="neco-code-header">
              <span className="neco-code-meta">{lineCount}줄 · {charCount}자</span>
              <button
                className={`neco-copy-btn ${copied ? 'copied' : ''}`}
                onClick={handleCopy}
                title="클립보드에 복사"
              >
                {copied ? '✓ 복사됨' : '복사'}
              </button>
            </div>
            <pre className="neco-code-block"><code>{payload.code}</code></pre>
          </>
        ) : (
          <div className="neco-empty">
            <span className="neco-empty-icon">↑</span>
            <p>에디터에서 코드를 드래그해서 선택하면<br />여기에 표시돼요</p>
          </div>
        )}
      </div>

      <footer className="neco-footer">
        NECO · 친절한 AI 코딩 친구
      </footer>
    </div>
  );
}

export default App;
